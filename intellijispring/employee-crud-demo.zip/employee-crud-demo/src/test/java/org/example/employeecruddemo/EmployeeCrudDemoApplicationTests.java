package org.example.employeecruddemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

//@SpringBootTest
class EmployeeCrudDemoApplicationTests {

    @Test
    void contextLoads() {
    }

}
